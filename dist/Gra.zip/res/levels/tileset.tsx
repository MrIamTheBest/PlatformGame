<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileset" tilewidth="32" tileheight="32" tilecount="9" columns="9">
 <image source="../textures/tilesets/tileset.png" width="288" height="32"/>
</tileset>
